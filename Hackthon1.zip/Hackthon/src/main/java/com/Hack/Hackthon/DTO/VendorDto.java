package com.Hack.Hackthon.DTO;

public class VendorDto {
}
