package com.Hack.Hackthon.DTO;


import com.sun.istack.NotNull;
import lombok.Data;

@Data
public class RegistrationDto {


    private long id;


    @NotNull
    private String firstName;

    @NotNull
    private String lastName;

    @NotNull
    private String zipcode;

    @NotNull
    private String State;

    @NotNull
    private String city;

    @NotNull
    private String  phoneNumber;

     @NotNull
    private String email;
}
