package com.Hack.Hackthon.Controller;


import com.Hack.Hackthon.DTO.RegistrationDto;
import com.Hack.Hackthon.Service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService;


    @PostMapping("/sign-up")
    public ResponseEntity  addUser(@RequestBody @Valid RegistrationDto registrationDto){


        registrationService.addUser(registrationDto);

        return new ResponseEntity("Registered Successfully", HttpStatus.OK);

    }

//    @PostMapping("/sign-up")
//    public ResponseEntity  addUser(@RequestBody @Valid RegistrationDto registrationDto){
//
//
//        registrationService.addUser(registrationDto);
//
//        return new ResponseEntity("Registered Successfully", HttpStatus.OK);
//
//    }
//


}
