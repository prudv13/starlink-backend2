package com.Hack.Hackthon.Exception;

public class ResourceAlreadyExistsException  extends RuntimeException {
    public ResourceAlreadyExistsException(String message) {
        super(message);
    }
}
