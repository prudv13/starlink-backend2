package com.Hack.Hackthon.Service;

import com.Hack.Hackthon.DTO.RegistrationDto;
import com.Hack.Hackthon.Dao.RegistrationRepository;
import com.Hack.Hackthon.Entity.RegistrationForm;
import com.Hack.Hackthon.Exception.RegistrationCustomException;
import com.Hack.Hackthon.Exception.ResourceAlreadyExistsException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    @Autowired
    RegistrationRepository registrationRepository;
    public void addUser(RegistrationDto registrationDto) {

        RegistrationForm registrationForm = new RegistrationForm();
        ModelMapper modelMapper = new ModelMapper();
        if(registrationDto == null){

            throw new RuntimeException("Please Enter All the Required Details");
        } else if(registrationRepository.existsByEmail(registrationDto.getEmail())){

            throw  new RegistrationCustomException("502","email already exists,Please register with different email-id");
        }else if(registrationRepository.existsByPhoneNumber(registrationDto.getPhoneNumber())){

            throw new ResourceAlreadyExistsException("Phone number  exists,please register with  different PhoneNumber");

        }else{

            modelMapper.map(registrationDto ,registrationForm);
            registrationRepository.save(registrationForm);

        }




        }


            }

