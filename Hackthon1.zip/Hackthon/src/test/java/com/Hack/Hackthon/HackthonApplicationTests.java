package com.Hack.Hackthon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackthonApplicationTests {

	@Test
	void contextLoads() {
	}

}
